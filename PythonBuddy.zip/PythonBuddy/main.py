#!/usr/bin/env python3
"""
PythonBuddy - Your Python Learning Companion
A hybrid assistant combining rule-based responses with DeepSeek AI
"""

import os
from openai import OpenAI


class PythonBuddy:
    """
    A class-based Python coding assistant that provides code examples
    and explanations based on keyword detection.
    """
    
    def __init__(self):
        """Initialize the PythonBuddy assistant"""
        self.topics = {
            'reverse_list': self._reverse_list_response,
            'sort': self._sort_response,
            'read_file': self._read_file_response,
            'write_file': self._write_file_response,
            'for_loop': self._for_loop_response,
            'while_loop': self._while_loop_response,
            'function': self._function_response,
            'list': self._list_response,
            'dictionary': self._dictionary_response,
            'string': self._string_response,
            'conditional': self._conditional_response,
        }
        
        # Initialize DeepSeek AI client
        self.api_key = os.getenv('DEEPSEEK_API_KEY')
        if self.api_key:
            self.client = OpenAI(
                api_key=self.api_key,
                base_url="https://api.deepseek.com"
            )
        else:
            self.client = None
    
    def get_response(self, question, chat_history=None):
        """
        Analyzes the user's question and returns a helpful code example
        based on detected keywords (rule-based) or AI for complex questions.
        
        Args:
            question (str): The user's Python coding question
            chat_history (list): Optional chat history for context
            
        Returns:
            str: A formatted response with code examples and explanations
        """
        question_lower = question.lower()
        
        # Try rule-based responses first (instant, no API cost)
        if self._is_print_question(question_lower):
            return self._print_response()
        elif self._is_variable_question(question_lower):
            return self._variable_response()
        elif self._is_input_question(question_lower):
            return self._input_response()
        elif self._is_error_handling_question(question_lower):
            return self._error_handling_response()
        elif self._is_class_question(question_lower):
            return self._class_response()
        elif self._is_import_question(question_lower):
            return self._import_response()
        elif self._is_reverse_list_question(question_lower):
            return self._reverse_list_response()
        elif self._is_sort_question(question_lower):
            return self._sort_response()
        elif self._is_read_file_question(question_lower):
            return self._read_file_response()
        elif self._is_write_file_question(question_lower):
            return self._write_file_response()
        elif self._is_while_loop_question(question_lower):
            return self._while_loop_response()
        elif self._is_for_loop_question(question_lower):
            return self._for_loop_response()
        elif self._is_function_question(question_lower):
            return self._function_response()
        elif self._is_list_question(question_lower):
            return self._list_response()
        elif self._is_dictionary_question(question_lower):
            return self._dictionary_response()
        elif self._is_string_question(question_lower):
            return self._string_response()
        elif self._is_conditional_question(question_lower):
            return self._conditional_response()
        else:
            # Use AI for complex questions, debugging, or custom requests
            return self._ai_response(question, chat_history)
    
    def _is_reverse_list_question(self, question):
        """Check if question is about reversing lists"""
        return "reverse" in question and ("list" in question or "array" in question)
    
    def _is_sort_question(self, question):
        """Check if question is about sorting"""
        return "sort" in question
    
    def _is_read_file_question(self, question):
        """Check if question is about reading files"""
        return "read" in question and "file" in question
    
    def _is_write_file_question(self, question):
        """Check if question is about writing files"""
        return "write" in question and "file" in question
    
    def _is_for_loop_question(self, question):
        """Check if question is about for loops"""
        return "loop" in question or "for loop" in question
    
    def _is_while_loop_question(self, question):
        """Check if question is about while loops"""
        return "while" in question
    
    def _is_function_question(self, question):
        """Check if question is about functions"""
        return "function" in question or "def" in question
    
    def _is_list_question(self, question):
        """Check if question is about lists"""
        return "list" in question and "create" in question
    
    def _is_dictionary_question(self, question):
        """Check if question is about dictionaries"""
        return "dictionary" in question or "dict" in question
    
    def _is_string_question(self, question):
        """Check if question is about strings"""
        return "string" in question
    
    def _is_conditional_question(self, question):
        """Check if question is about if/else statements"""
        return "if" in question or "condition" in question
    
    def _is_print_question(self, question):
        """Check if question is about print statements"""
        return "print" in question or "output" in question or "display" in question
    
    def _is_variable_question(self, question):
        """Check if question is about variables"""
        return "variable" in question or "assign" in question
    
    def _is_input_question(self, question):
        """Check if question is about user input"""
        return "input" in question or "get input" in question
    
    def _is_error_handling_question(self, question):
        """Check if question is about error handling"""
        return ("error" in question or "exception" in question or "try" in question) and ("handle" in question or "catch" in question or "except" in question)
    
    def _is_class_question(self, question):
        """Check if question is about classes"""
        return "class" in question or "object" in question and "create" in question
    
    def _is_import_question(self, question):
        """Check if question is about imports"""
        return "import" in question or "module" in question or "package" in question
    
    def _reverse_list_response(self):
        """Return response for reversing lists"""
        return """
📝 How to Reverse a List:

# Method 1: Using reverse() method (modifies original list)
my_list = [1, 2, 3, 4, 5]
my_list.reverse()
print(my_list)  # Output: [5, 4, 3, 2, 1]

# Method 2: Using slicing (creates new list)
my_list = [1, 2, 3, 4, 5]
reversed_list = my_list[::-1]
print(reversed_list)  # Output: [5, 4, 3, 2, 1]

# Method 3: Using reversed() function
my_list = [1, 2, 3, 4, 5]
reversed_list = list(reversed(my_list))
print(reversed_list)  # Output: [5, 4, 3, 2, 1]

💡 Explanation: The [::-1] slicing is most common. It means "start at the end 
   and go backwards with step -1".
"""
    
    def _sort_response(self):
        """Return response for sorting"""
        return """
📝 How to Sort a List:

# Method 1: Using sort() method (modifies original list)
numbers = [5, 2, 8, 1, 9]
numbers.sort()
print(numbers)  # Output: [1, 2, 5, 8, 9]

# Sort in descending order
numbers.sort(reverse=True)
print(numbers)  # Output: [9, 8, 5, 2, 1]

# Method 2: Using sorted() function (creates new list)
numbers = [5, 2, 8, 1, 9]
sorted_numbers = sorted(numbers)
print(sorted_numbers)  # Output: [1, 2, 5, 8, 9]

# Sort strings alphabetically
words = ["banana", "apple", "cherry"]
words.sort()
print(words)  # Output: ['apple', 'banana', 'cherry']

💡 Explanation: sort() changes the original list, sorted() creates a new one.
"""
    
    def _read_file_response(self):
        """Return response for reading files"""
        return """
📝 How to Read a File:

# Method 1: Read entire file at once
with open("filename.txt", "r") as file:
    content = file.read()
    print(content)

# Method 2: Read line by line
with open("filename.txt", "r") as file:
    for line in file:
        print(line.strip())  # strip() removes extra whitespace

# Method 3: Read all lines into a list
with open("filename.txt", "r") as file:
    lines = file.readlines()
    print(lines)

💡 Explanation: Using 'with' automatically closes the file when done. 
   The "r" means read mode.
"""
    
    def _write_file_response(self):
        """Return response for writing files"""
        return """
📝 How to Write to a File:

# Method 1: Write text to a file (overwrites existing content)
with open("output.txt", "w") as file:
    file.write("Hello, World!\\n")
    file.write("This is a new line.\\n")

# Method 2: Append to a file (adds to existing content)
with open("output.txt", "a") as file:
    file.write("This is appended text.\\n")

# Method 3: Write multiple lines at once
lines = ["Line 1\\n", "Line 2\\n", "Line 3\\n"]
with open("output.txt", "w") as file:
    file.writelines(lines)

💡 Explanation: "w" = write (overwrites), "a" = append (adds to end).
   Use \\n for new lines.
"""
    
    def _for_loop_response(self):
        """Return response for for loops"""
        return """
📝 How to Use For Loops:

# Loop through a range of numbers
for i in range(5):
    print(i)  # Prints: 0, 1, 2, 3, 4

# Loop through a list
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)

# Loop with index and value
for index, fruit in enumerate(fruits):
    print(f"{index}: {fruit}")

# Loop through a range with custom start and step
for i in range(2, 10, 2):
    print(i)  # Prints: 2, 4, 6, 8

💡 Explanation: For loops repeat code for each item in a sequence.
   range(5) creates numbers 0-4. enumerate() gives both index and value.
"""
    
    def _while_loop_response(self):
        """Return response for while loops"""
        return """
📝 How to Use While Loops:

# Basic while loop
count = 0
while count < 5:
    print(count)
    count += 1  # Same as: count = count + 1

# While loop with break
count = 0
while True:
    print(count)
    count += 1
    if count >= 5:
        break  # Exit the loop

# While loop with user input
answer = ""
while answer.lower() != "yes":
    answer = input("Are we done? (yes/no): ")

💡 Explanation: While loops continue as long as the condition is True.
   Be careful to avoid infinite loops!
"""
    
    def _function_response(self):
        """Return response for functions"""
        return """
📝 How to Create Functions:

# Basic function
def greet():
    print("Hello!")

greet()  # Call the function

# Function with parameters
def greet_person(name):
    print(f"Hello, {name}!")

greet_person("Alice")  # Output: Hello, Alice!

# Function with return value
def add_numbers(a, b):
    return a + b

result = add_numbers(5, 3)
print(result)  # Output: 8

# Function with default parameter
def greet_with_message(name, message="Welcome!"):
    print(f"{name}, {message}")

greet_with_message("Bob")  # Output: Bob, Welcome!

💡 Explanation: Functions are reusable blocks of code. Use 'def' to define them,
   and 'return' to send back a value.
"""
    
    def _list_response(self):
        """Return response for lists"""
        return """
📝 How to Work with Lists:

# Create a list
my_list = [1, 2, 3, 4, 5]
fruits = ["apple", "banana", "cherry"]
mixed = [1, "hello", True, 3.14]

# Add items to a list
fruits.append("orange")  # Add to end
fruits.insert(1, "grape")  # Insert at index 1

# Remove items from a list
fruits.remove("banana")  # Remove by value
last_item = fruits.pop()  # Remove and return last item
del fruits[0]  # Remove by index

# Access list items
first = fruits[0]  # First item
last = fruits[-1]  # Last item
subset = fruits[1:3]  # Slice: items at index 1 and 2

💡 Explanation: Lists are ordered collections that can hold any type of data.
   They're mutable, meaning you can change them after creation.
"""
    
    def _dictionary_response(self):
        """Return response for dictionaries"""
        return """
📝 How to Work with Dictionaries:

# Create a dictionary
person = {
    "name": "Alice",
    "age": 25,
    "city": "New York"
}

# Access values
print(person["name"])  # Output: Alice
print(person.get("age"))  # Output: 25

# Add or modify items
person["email"] = "alice@email.com"  # Add new key
person["age"] = 26  # Update existing value

# Remove items
del person["city"]  # Remove a key-value pair
email = person.pop("email")  # Remove and return value

# Loop through dictionary
for key, value in person.items():
    print(f"{key}: {value}")

💡 Explanation: Dictionaries store key-value pairs. Use keys to access values.
   Keys must be unique and immutable (strings, numbers, tuples).
"""
    
    def _string_response(self):
        """Return response for strings"""
        return """
📝 How to Work with Strings:

# Create strings
text = "Hello, World!"
multiline = '''This is
a multiline
string'''

# Common string methods
print(text.lower())  # Convert to lowercase
print(text.upper())  # Convert to uppercase
print(text.replace("World", "Python"))  # Replace text
print(text.split(","))  # Split into list

# String slicing
print(text[0:5])  # First 5 characters: "Hello"
print(text[-6:])  # Last 6 characters: "World!"

# String formatting
name = "Alice"
age = 25
print(f"My name is {name} and I'm {age} years old.")

💡 Explanation: Strings are text data. Use f-strings (f"...") for easy formatting.
   Strings are immutable - methods create new strings.
"""
    
    def _conditional_response(self):
        """Return response for if/else statements"""
        return """
📝 How to Use If/Else Statements:

# Basic if statement
age = 18
if age >= 18:
    print("You are an adult")

# If-else statement
age = 16
if age >= 18:
    print("You are an adult")
else:
    print("You are a minor")

# If-elif-else statement
score = 85
if score >= 90:
    print("Grade: A")
elif score >= 80:
    print("Grade: B")
elif score >= 70:
    print("Grade: C")
else:
    print("Grade: F")

# Multiple conditions
age = 25
has_license = True
if age >= 18 and has_license:
    print("You can drive")

💡 Explanation: If statements let you execute code based on conditions.
   Use 'and', 'or', 'not' for multiple conditions.
"""
    
    def _print_response(self):
        """Return response for print statements"""
        return """
📝 How to Use Print in Python:

# Basic print
print("Hello, World!")

# Print multiple items
print("Hello", "World", "!")  # Output: Hello World !

# Print with custom separator
print("Hello", "World", sep="-")  # Output: Hello-World

# Print without newline
print("Hello", end=" ")
print("World!")  # Output: Hello World!

# Print variables
name = "Alice"
age = 25
print("My name is", name, "and I'm", age)

# Print with f-strings (formatted strings)
print(f"My name is {name} and I'm {age} years old")

# Print with format()
print("My name is {} and I'm {}".format(name, age))

💡 Explanation: print() outputs text to the console. Use f-strings for easy formatting!
"""
    
    def _variable_response(self):
        """Return response for variables"""
        return """
📝 How to Use Variables in Python:

# Creating variables (no need to declare type)
name = "Alice"          # String
age = 25                # Integer
height = 5.6            # Float
is_student = True       # Boolean

# Multiple assignment
x = y = z = 0

# Unpacking values
a, b, c = 1, 2, 3

# Variable naming rules
my_variable = "valid"   # snake_case (recommended)
myVariable = "valid"    # camelCase
_private = "valid"      # starts with underscore
# 2variable = "invalid" # can't start with number

# Changing variable type (dynamic typing)
x = 5          # x is int
x = "Hello"    # now x is string

# Constants (by convention, use UPPERCASE)
PI = 3.14159
MAX_SIZE = 100

💡 Explanation: Variables store data. Python is dynamically typed, so you don't need to declare types!
"""
    
    def _input_response(self):
        """Return response for user input"""
        return """
📝 How to Get User Input:

# Basic input (returns string)
name = input("What's your name? ")
print(f"Hello, {name}!")

# Converting input to integer
age = int(input("What's your age? "))
print(f"You are {age} years old")

# Converting input to float
price = float(input("Enter price: "))
print(f"Price: ${price}")

# Getting multiple inputs
x, y = input("Enter two numbers (space-separated): ").split()
x = int(x)
y = int(y)
print(f"Sum: {x + y}")

# Input with error handling
try:
    number = int(input("Enter a number: "))
    print(f"You entered: {number}")
except ValueError:
    print("That's not a valid number!")

💡 Explanation: input() always returns a string. Use int() or float() to convert!
"""
    
    def _error_handling_response(self):
        """Return response for error handling"""
        return """
📝 How to Handle Errors (Try/Except):

# Basic try-except
try:
    number = int(input("Enter a number: "))
    result = 100 / number
    print(f"Result: {result}")
except ValueError:
    print("Please enter a valid number!")
except ZeroDivisionError:
    print("Cannot divide by zero!")

# Catch all exceptions
try:
    risky_operation()
except Exception as e:
    print(f"An error occurred: {e}")

# Try-except-else-finally
try:
    file = open("data.txt", "r")
    data = file.read()
except FileNotFoundError:
    print("File not found!")
else:
    print("File read successfully!")
finally:
    file.close()  # Always executes

# Raising exceptions
def check_age(age):
    if age < 0:
        raise ValueError("Age cannot be negative!")
    return age

💡 Explanation: Use try-except to handle errors gracefully and prevent crashes!
"""
    
    def _class_response(self):
        """Return response for classes"""
        return """
📝 How to Create Classes (Object-Oriented Programming):

# Basic class
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def greet(self):
        print(f"Hello, I'm {self.name} and I'm {self.age}")

# Creating objects
person1 = Person("Alice", 25)
person2 = Person("Bob", 30)

person1.greet()  # Output: Hello, I'm Alice and I'm 25

# Class with methods
class Calculator:
    def add(self, a, b):
        return a + b
    
    def subtract(self, a, b):
        return a - b

calc = Calculator()
print(calc.add(5, 3))  # Output: 8

# Inheritance
class Student(Person):
    def __init__(self, name, age, grade):
        super().__init__(name, age)
        self.grade = grade
    
    def study(self):
        print(f"{self.name} is studying")

student = Student("Charlie", 20, "A")
student.greet()
student.study()

💡 Explanation: Classes are blueprints for creating objects with properties and methods!
"""
    
    def _import_response(self):
        """Return response for imports"""
        return """
📝 How to Import Modules:

# Import entire module
import math
print(math.sqrt(16))  # Output: 4.0
print(math.pi)        # Output: 3.14159...

# Import specific functions
from math import sqrt, pi
print(sqrt(16))  # No need for math.sqrt
print(pi)

# Import with alias
import pandas as pd
import numpy as np

# Import all (not recommended)
from math import *

# Import your own module
# If you have a file called my_module.py:
import my_module
my_module.my_function()

# Common useful modules
import random          # Random numbers
import datetime        # Dates and times
import json           # JSON data
import os             # Operating system operations

# Using random module
print(random.randint(1, 10))  # Random number 1-10
print(random.choice(['a', 'b', 'c']))  # Random choice

💡 Explanation: import lets you use code from other modules and libraries!
"""
    
    def _ai_response(self, question, chat_history=None):
        """
        Use DeepSeek AI for complex questions, debugging, and custom requests
        
        Args:
            question (str): The user's question
            chat_history (list): Previous conversation for context
            
        Returns:
            str: AI-generated response
        """
        if not self.client:
            return self._fallback_response()
        
        try:
            # Build messages for AI context
            messages = [
                {
                    "role": "system",
                    "content": """You are PythonBuddy, a friendly Python coding assistant for beginners. 
                    
Your role:
- Explain Python concepts in simple, beginner-friendly language
- Provide clear, working code examples
- Help debug code and fix errors
- Answer questions about Python programming
- Use emojis occasionally to be friendly (📝 ✅ 💡)
- Keep explanations concise but complete
- Always include code examples when relevant

When helping with code:
- Show the complete, working solution
- Explain what the code does
- Point out common mistakes
- Suggest best practices

Keep responses focused and practical!"""
                }
            ]
            
            # Add chat history for context
            if chat_history:
                for msg in chat_history[-6:]:  # Last 6 messages for context
                    messages.append({
                        "role": msg.get("role", "user"),
                        "content": msg.get("content", "")
                    })
            
            # Add current question
            messages.append({
                "role": "user",
                "content": question
            })
            
            # Call DeepSeek API
            response = self.client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                temperature=0.7,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"""
🤖 AI Response (DeepSeek):

I encountered an error while processing your question: {str(e)}

Please try:
• Rephrasing your question
• Asking about basic Python topics (print, variables, loops, etc.)
• Checking if your question is clear and specific

Or try asking: "How do I create a function?" or "Help me fix this error"
"""
    
    def _fallback_response(self):
        """Return fallback response when AI is not available"""
        return """
❓ I'm still learning! Try asking about:
   • Print statements
   • Variables
   • User input
   • Error handling (try/except)
   • Classes and objects
   • Imports and modules
   • Reversing & sorting lists
   • Reading & writing files
   • Loops (for/while)
   • Functions
   • Lists & dictionaries
   • Strings
   • If/else statements
   
Example: "How do I print Hello World?" or "How to handle errors?"
"""


def get_response(question):
    """
    Convenience function for backwards compatibility.
    Creates a PythonBuddy instance and gets a response.
    
    Args:
        question (str): The user's Python coding question
        
    Returns:
        str: A formatted response with code examples and explanations
    """
    buddy = PythonBuddy()
    return buddy.get_response(question)


def main():
    """
    Main function that runs PythonBuddy in console mode
    """
    buddy = PythonBuddy()
    
    print("=" * 60)
    print("🐍 Welcome to PythonBuddy!")
    print("=" * 60)
    print("\nHi there! I'm your Python learning companion.")
    print("Ask me common Python questions and I'll provide code examples.\n")
    print("Type 'exit' or 'quit' to leave.\n")
    
    while True:
        question = input("🎯 Your question: ").strip()
        
        if question.lower() in ['exit', 'quit', 'bye', 'q']:
            print("\n👋 Happy coding! Keep practicing and you'll become a Python pro!")
            break
        
        if not question:
            print("Please type a question!\n")
            continue
        
        response = buddy.get_response(question)
        print(response)
        print()


if __name__ == "__main__":
    main()
