# PythonBuddy

## Overview
A beginner-friendly Python learning companion web application that uses a hybrid approach combining rule-based keyword matching for instant responses with DeepSeek AI for complex questions. Features persistent chat storage, sharing, export functionality, and comprehensive security hardening. Uses Python's official blue and yellow color scheme with customizable themes.

## Features
- **Hybrid AI System**: Rule-based responses for basic questions (instant, no API cost) + DeepSeek AI for complex questions, debugging, and custom requests
- **Persistent Chat Storage**: All chats saved in localStorage with quota management (no login required)
- **Share Chats**: Generate shareable links for conversations with public view (stored in-memory)
- **Export to .txt**: Download chat conversations as formatted text files
- **Theme Switcher**: Light/Dark/System modes with localStorage persistence and auto-detection
- **Responsive Design**: Mobile-first design optimized for smartphones, tablets, and desktops
- **Security Hardened**: XSS protection, input validation, localStorage quota management, error handling
- Web-based interface accessible via browser
- **17+ Python Topics** including:
  - Print statements & output
  - Variables & data types
  - User input
  - Error handling (try/except)
  - Classes & object-oriented programming
  - Imports & modules
  - Reversing and sorting lists
  - Reading and writing files
  - For and while loops
  - Functions
  - Lists and dictionaries
  - Strings and if/else statements
- **Chat Session Management** like ChatGPT:
  - Create multiple chat conversations
  - Rename chats for specific topics (pencil icon)
  - Switch between chats easily
  - Delete old conversations
  - Auto-naming based on first question
- Beautiful, modern chat interface with sidebar
- Quick-start example buttons for common topics
- Beginner-friendly with emojis and simple language

## How to Use
1. Open the web application in your browser
2. Type your Python coding question in the input field
3. Click "Send" or press Enter
4. Get instant code examples and explanations in a chat-style interface
5. Use the example buttons for quick common questions

## Project Structure
- `app.py` - Flask web server with share chat endpoints (/share, /shared/<id>)
- `main.py` - Core PythonBuddy class with modular functions for keyword detection and responses
- `templates/index.html` - Main web interface with responsive design, theme switcher, and security features
- `templates/shared.html` - Public view template for shared chat conversations

## Technical Architecture
- **Hybrid Response System**: 
  - Rule-based keyword matching for 17+ Python topics (instant responses)
  - DeepSeek AI fallback for complex questions with chat history context
- **PythonBuddy Class**: Object-oriented design with separate methods for each topic
- **AI Integration**: OpenAI-compatible client using DeepSeek API
- **Frontend**: 
  - localStorage for persistent storage with quota management (auto-cleanup when full)
  - Export to .txt functionality
  - CSS variables-based theming system (Light/Dark/System auto-detection)
  - Responsive design with mobile-first approach
  - XSS protection via escapeHtml() function for all user inputs
- **Share System**: Backend endpoints for creating/retrieving shareable chat links with public view template
- **Security**: 
  - API keys managed through Replit Secrets (environment variables)
  - XSS protection on frontend (escapeHtml) and backend (Jinja2 explicit escaping)
  - Input validation (question: 2000 chars, history: 100 msgs, share: 500 msgs)
  - localStorage quota management with graceful degradation
  - Debug mode disabled for production
  - Comprehensive error handling for all async operations

## Recent Changes
- 2025-10-08: **Revamped Messaging** - Updated header and welcome message to be more engaging and highlight AI-powered features
- 2025-10-08: **Rename Chat Feature** - Added pencil icon to rename any chat for specific topics (max 50 characters)
- 2025-10-08: **Delete Last Chat Fix** - Allow deleting the last chat session (auto-creates a fresh new one), removing the "You need at least one chat session!" restriction
- 2025-10-08: **Critical Bug Fix** - Fixed localStorage quota handling to correctly preserve 5 NEWEST chats (slice(-5)) with save-before-mutate logic for data consistency
- 2025-10-08: **Security Hardening** - Added XSS protection (escapeHtml), input validation, localStorage quota management, error handling
- 2025-10-08: **Simplified to English-only** - Removed multi-language support for better Python learning experience (Python is best learned in English)
- 2025-10-08: **Bug Fixes & Optimization** - Added localStorage quota management (auto-cleanup), comprehensive error handling, removed unused code
- 2025-10-08: **Production Ready** - Debug mode disabled, input validation (2000 chars), graceful error degradation
- 2025-10-08: **Theme Switcher** - Implemented light/dark/system theme modes with CSS variables and localStorage persistence
- 2025-10-08: **Share Chat Feature** - Added shareable links functionality with public view template and sidebar display
- 2025-10-08: **Responsive Design** - Mobile-first responsive design with hamburger menu, optimized for smartphones and tablets
- 2025-10-07: **Hybrid AI Integration** - Added DeepSeek AI for complex questions while keeping rule-based responses for basic topics
- 2025-10-07: **Persistent Storage** - Implemented localStorage to save all chats across page refreshes (no login required)
- 2025-10-07: **Export Feature** - Added .txt export functionality for downloading chat conversations
- 2025-10-07: **Color Scheme Update** - Applied Python's official blue (#3776AB) and yellow (#FFD43B) colors throughout UI
