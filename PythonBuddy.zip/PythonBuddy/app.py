#!/usr/bin/env python3
"""
Flask Web Server for the AI Coding Assistant
"""

from flask import Flask, render_template, request, jsonify
from main import PythonBuddy
import secrets
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(16)
buddy = PythonBuddy()

# In-memory storage for shared chats (consider using database for production)
shared_chats = {}

@app.after_request
def add_header(response):
    """Add headers to prevent caching"""
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@app.route('/')
def home():
    """Serve the main page"""
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    """Handle questions from users and return responses"""
    data = request.get_json()
    question = data.get('question', '').strip()
    chat_history = data.get('chat_history', [])
    
    if not question:
        return jsonify({'response': 'Please type a question!'})
    
    # Security: Input validation
    if len(question) > 2000:
        return jsonify({'response': 'Question is too long. Please keep it under 2000 characters.'})
    
    if len(chat_history) > 100:
        return jsonify({'response': 'Chat history is too long. Please start a new chat.'})
    
    # Use PythonBuddy instance to get response with chat history
    response = buddy.get_response(question, chat_history)
    return jsonify({'response': response})

@app.route('/share', methods=['POST'])
def share_chat():
    """Create a shareable link for a chat session"""
    data = request.get_json()
    chat_title = data.get('title', 'Untitled Chat')
    messages = data.get('messages', [])
    
    if not messages:
        return jsonify({'error': 'No messages to share'}), 400
    
    # Security: Input validation
    if len(chat_title) > 100:
        chat_title = chat_title[:100]
    
    if len(messages) > 500:
        return jsonify({'error': 'Too many messages to share. Maximum is 500.'}), 400
    
    # Generate unique share ID
    share_id = secrets.token_urlsafe(12)
    
    # Store chat with metadata
    shared_chats[share_id] = {
        'title': chat_title,
        'messages': messages,
        'created_at': datetime.now().isoformat(),
        'view_count': 0
    }
    
    return jsonify({
        'share_id': share_id,
        'url': f'/shared/{share_id}'
    })

@app.route('/shared/<share_id>')
def view_shared_chat(share_id):
    """View a shared chat (public access)"""
    if share_id not in shared_chats:
        return "Chat not found", 404
    
    # Increment view count
    shared_chats[share_id]['view_count'] += 1
    
    chat_data = shared_chats[share_id]
    return render_template('shared.html', 
                         title=chat_data['title'],
                         messages=chat_data['messages'],
                         created_at=chat_data['created_at'])

@app.route('/api/shared/<share_id>')
def get_shared_chat_api(share_id):
    """API endpoint to get shared chat data"""
    if share_id not in shared_chats:
        return jsonify({'error': 'Chat not found'}), 404
    
    return jsonify(shared_chats[share_id])

if __name__ == '__main__':
    # Security: Debug mode disabled for production
    app.run(host='0.0.0.0', port=5000, debug=False)
